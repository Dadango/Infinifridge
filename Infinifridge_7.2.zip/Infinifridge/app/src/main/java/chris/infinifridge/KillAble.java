package chris.infinifridge;

import android.os.Bundle;
import android.os.Environment;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class KillAble extends AppCompatActivity{
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        saver();
        try {
            this.finalize();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        this.finish();

    }

    @Override
    protected void onResume() {
        super.onResume();
        saver();
        try {
            this.finalize();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        this.finish();
    }
    public void saver() {
        Toast.makeText(this, "You have saved your entries", Toast.LENGTH_SHORT).show();
        //from line 144-165, Save the information from myEntries into a saveFile called entries.json
        JSONArray jj = new JSONArray();                                                             //Declares and initializes a new JSONArray with the name jj
        for (int i = 0; i < Home.myEntries.size(); i++) {                                                //For loop that keeps running until 'i' reaches the size of myEntries (runs for each element in the myEntries array)
            JsonSaver j = new JsonSaver(Home.myEntries.get(i));                                //Declares and initializes a new variable with the name j that is a new object of the jsonSaver Class that gets the Entries object from the 'i'th spot of the ArrayList myEntries
            jj.put(j);                                                                              //Put the JSONObject j into the JSONArray jj
        }                                                                                           //This loop has effectively converted the Entries objects in the myEntries ArrayList into a JSONArray named jj
        Writer output;                                                                              //Declares the variable "output" with the type Writer

        File saveDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "/Infinifridge"); //Creates a new directory named infinifridge in the external storage directory
        if (!saveDir.exists()){
            saveDir.mkdir();
        }
        File saveFile = new File(saveDir, "entries.json");                                     //Creates a new File called saveFile that is to be saved in the save directory infinifridge(saveDir) with the name Entries.json
        try {                                                                                       //Exception handling for IOException
            output = new BufferedWriter(new FileWriter(saveFile));                                  //Assigns "output" to a new BufferedReader, to buffer the output from the FileReader, with the save file (saveFile) being written to
            output.write(jj.toString());                                                            //Converts jj to a string and writes the String onto the file using "output"
            output.close();                                                                         //Flushes the characters from the stream and then closes it
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
