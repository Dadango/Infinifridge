package chris.infinifridge;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class Home extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    static ArrayList<Entries> myEntries = new ArrayList();                                                   // initializing a new ArrayList called myEntries
    static boolean deletionMode = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //from line 36-69, loads all information about entries from the save file, Entries.json
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "/Infinifridge" + File.separator + "entries.json"; //saves the path as a String for readability
        BufferedReader br = null;                                                                   //Declares the variable "br" and initializes it to 'null', because the variable is declared in a method
        try {                                                                                       //Exception handling for FileNotFoundException
            br = new BufferedReader(new FileReader(path));                                          //Assigns br to a new BufferedReader, to buffer the input from the FileReader, with the save file being the file to read from
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        String jasonA = "";                                                                         //Declares and initializes the variable jasonA to a blank string
        if (br != null) {                                                                           //If-statement to avoid a nullPointException, running only if the BufferedReader exists (is not null)
            try {                                                                                   //Exception handling for IOException
                jasonA = br.readLine();                                                             //Assigns the buffered input from the FileReader as a String to jasonA.
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        JSONArray jason = null;                                                                     //Declares and initializes a JSONArray called "jason" to 'null'
        try {                                                                                       //Exception handling for JSONException
            jason = new JSONArray(jasonA);                                                          //jasonA is the save file converted into a String, which lets us import that into a JSONArray
            // directly (as this is how it is saved in the first place), an assign "jason" to this new JSONArray.
            myEntries.clear();                                                                      //Clears all elements in the myEntries array, effectively removing them and resizing the Array to 0
            for (int i = 0; i < jasonA.length(); i++) {                                             //Creates a for loop that runs from 0 to the length of the jasonA array (actually it goes the length of the String rn?
                JSONObject jasonO = jason.getJSONObject(i);                                         //Declares and initializes a new JSONObject called jasonO, that is assigns the value of jason for each iteration of i
                String name = jasonO.getString("Name");                                       //Declares and initializes a new string called name that is assigned the value "Name" from JasonO (jason object)
                int imageId = Integer.parseInt(jasonO.getString("ImageID"));                  //Declares and initializes a new integer called imageID that is assigned the value "ImageID" from jasonO (jason object)
                int amount = Integer.parseInt(jasonO.getString("Amount"));                    //Declares and initializes a new integer called amount that is assigned the value "Amount" from jasonO (jason object)
                int amountType = Integer.parseInt(jasonO.getString("AmountType"));            //Declares and initializes a new integer called amountType that is assigned the value "AmountType" frmo jasonO (jason object)
                int storage = Integer.parseInt(jasonO.getString("Storage"));                  //Declares and initializes a new integer called storage that is assigned the value "Storage" from jasonO (jason object)
                int[] expiryDate = {Integer.parseInt(jasonO.getString("ExpD")), Integer.parseInt(jasonO.getString("ExpM")), Integer.parseInt(jasonO.getString("ExpY"))};
                //^Declares and initializes a new integer array called expiryDate that is assigned three integer values: "ExpD", "ExpM" and "ExpY" from jasonO (jason object)
                int category = Integer.parseInt(jasonO.getString("Category"));
                myEntries.add(new Entries(name, imageId, amount, amountType, storage, expiryDate, category, myEntries.size())); //Add a new element to the myEntries arraylist with the values name, imageId, amount, amountType, storage and expiryDate, from above
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) //If-statement that checks if the application has permission to write to external storage
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1); // if it does not have permission it request permission from the user
        }
        spiderman();

    }

    @Override
    protected void onResume() {
        super.onResume();

        AddActivity.please = null;
        updateEntriesH(0);
        if (myEntries.size() == 0) {
            TextView tv = findViewById(R.id.tv_noItems);
            tv.setVisibility(View.VISIBLE);
        } else {
            TextView tv = findViewById(R.id.tv_noItems);
            tv.setVisibility(View.GONE);
        }
    }

    public void addNewButtonPressed(View v) {
        deletionMode = false;
        Intent intent = new Intent(this, AddActivity.class);                           //Clicking the add new button will start a new activity(AddActivity) from the home activity
        startActivity(intent);
    }

    public void spiderman() {

        setContentView(R.layout.activity_home);
        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        Spinner sortingID = findViewById(R.id.sortingSpiderMan);
        sortingID.setOnItemSelectedListener(this);
        List<String> list = new ArrayList<>();
        list.add("Oldest -> newest");
        list.add("Newest -> oldest");
        list.add("By category");
        list.add("Expiration date");
        list.add("Alphabetical");


        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortingID.setAdapter(adapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        updateEntriesH((int) id);
    }


    public void updateEntriesH(int id) {
        int size = myEntries.size();
        for (int i = 0; i < size; i++) {
            Log.i("MyEntriesEntries", myEntries.get(i).category + "");
        }
        GridView gridView = findViewById(R.id.gridViewHome);                                            //Declares and initializes a Gridview, found via the id of "gridViewHome" from the Content view
        if (myEntries != null) {
            boolean[] imageWar = new boolean[size];                                                         //Declares and initializes a new boolean array called imageWar with the same size as the myEntries arraylist
            String[] homeNames = new String[size];                                                      //Declares and initializes a new string array called homeNames with the same size/length as the myEntries arraylist
            int[] homeImageIds = new int[size];                                                         //Initializes a new integer array called homeImageIds with the same size as the myEntries arraylist

            switch (id) {
                case 0:
                    sortDefault(myEntries);
                    break;
                case 1:
                    sortDefault(myEntries);
                    sortReverse(myEntries);
                    break;
                case 2:
                    sortDefault(myEntries);
                    sortCategory(myEntries);
                    break;
                case 3:
                    sortDefault(myEntries);
                    sortExpDate(myEntries);
                    break;
                case 4:
                    sortDefault(myEntries);
                    sortAlphabet(myEntries);
                    break;
            }
            for (int i = 0; i < size; i++) {                                                             //A for loop that keeps running until 'i' reaches the length of myEntries
                Entries ph = myEntries.get(i);                                                //Declares and initializes a variable called ph with the type Entries, that gets its information from the 'i'th object of the meEntries array
                homeNames[i] = ph.name;                                                                 //Assigns the value of ph.name to the homeNames array for each iteration of i
                homeImageIds[i] = ph.imageId;                                                           //Assigns the value of ph.imageID to the homeImageIds array for each iteration of i
                imageWar[i] = ph.amIExpiringSoon();                                                     //Assigns the returned value of amIExpiringSoon (running the method returns a boolean) to the boolean array imageWar for each iteration of i
            }
            gridView.setAdapter(new GridAdapter(this, homeNames, homeImageIds, imageWar));  //Sets the gridview dependent on the values of homeNames, homeImageIds and imageWar (technically true, but functionally it uses the arrays to build a new grid adapter object from our GridAdapter Class)
        }


        /*if (myEntries != null) {
            boolean[] imageWar = new boolean[size];                                                         //Declares and initializes a new boolean array called imageWar with the same size as the myEntries arraylist
            String[] homeNames = new String[size];                                                      //Declares and initializes a new string array called homeNames with the same size/length as the myEntries arraylist
            int[] homeImageIds = new int[size];                                                         //Initializes a new integer array called homeImageIds with the same size as the myEntries arraylist
            for (int i = 0; i < size; i++) {                                                             //A for loop that keeps running until 'i' reaches the length of myEntries
                Entries ph = sortingArrs.get(id).get(i);                                                //Declares and initializes a variable called ph with the type Entries, that gets its information from the 'i'th object of the meEntries array
                homeNames[i] = ph.name;                                                                 //Assigns the value of ph.name to the homeNames array for each iteration of i
                homeImageIds[i] = ph.imageId;                                                           //Assigns the value of ph.imageID to the homeImageIds array for each iteration of i
                imageWar[i] = ph.amIExpiringSoon();                                                     //Assigns the returned value of amIExpiringSoon (running the method returns a boolean) to the boolean array imageWar for each iteration of i
            }
            gridView.setAdapter(new GridAdapter(this, homeNames, homeImageIds, imageWar));  //Sets the gridview dependent on the values of homeNames, homeImageIds and imageWar (technically true, but functionally it uses the arrays to build a new grid adapter object from our GridAdapter Class)
        }*/

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    public void sortDefault(ArrayList<Entries> al) {
        class SortByMySpot implements Comparator<Entries> {
            public int compare(Entries a, Entries b) {
                return a.mySpot - b.mySpot;
            }
        }
        Collections.sort(al, new SortByMySpot());
    }

    public void sortCategory(ArrayList<Entries> al) {
        class SortbyCategory implements Comparator<Entries> {
            public int compare(Entries a, Entries b) {
                return a.category - b.category;
            }
        }
        Collections.sort(al, new SortbyCategory());
   }

    public void sortReverse(ArrayList<Entries> al) {
        Collections.reverse(al);
    }

    public void sortExpDate(ArrayList<Entries> al) {
        class SortByExpDate implements Comparator<Entries> {
            public int compare(Entries a, Entries b) {
                return (int) (b.getExpirationDate(b.expirationDate[0], b.expirationDate[1], b.expirationDate[2]) -
                        a.getExpirationDate(a.expirationDate[0], a.expirationDate[1], a.expirationDate[2]));
            }
        }
        Collections.sort(al, new SortByExpDate());
    }

    public void sortAlphabet(ArrayList<Entries> al) {
        class SortByAlphabet implements Comparator<Entries> {
            public int compare(Entries a, Entries b) {
                return a.name.compareToIgnoreCase(b.name);
            }
        }
        Collections.sort(al, new SortByAlphabet());
    }

    public void clickBeatrice(View view) {
        deletionMode = !deletionMode;
        Button butt = findViewById(R.id.bt_deletionMode);
        if (deletionMode) {
            butt.setBackgroundColor(Color.RED);
        } else {
            butt.setBackgroundColor(Color.LTGRAY);
        }
    }

}
