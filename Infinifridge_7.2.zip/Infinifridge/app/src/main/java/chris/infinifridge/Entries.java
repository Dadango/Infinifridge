package chris.infinifridge;


import android.util.Log;

import java.text.ParseException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Date;

public class
Entries {                                                                              //The entries class, with it's variables and the default values of the variables are declared and initialized
    String name = "Custom entry";
    int imageId = 0;
    int amount = 1;
    int amountType = 0;
    int storage = 0;
    int[] expirationDate = new int[3];
    int category = -1;
    int mySpot = 0;

    public Entries() {
    }

    public Entries(String name, int imageId, int amount, int amountType, int storage, int[] catCol, int mySpot) {             //A non-default constructor, with every variable, except the expiration date, assigned to the arguments
        this.name = name;
        this.imageId = imageId;
        this.amount = amount;
        this.amountType = amountType;
        this.storage = storage;
        this.category = colorIdentifier(catCol);
        this.mySpot = mySpot;
    }

    public Entries(String name, int imageId, int amount, int amountType, int storage, int[] expirationDate, int[] catCol, int mySpot) {   //A non-default constructor, with every variable assigned to the argument values
        this.name = name;
        this.imageId = imageId;
        this.amount = amount;
        this.amountType = amountType;
        this.storage = storage;
        this.expirationDate = expirationDate;
        this.category = colorIdentifier(catCol);
        this.mySpot = mySpot;
    }

    public Entries(String name, int imageId, int amount, int amountType, int storage, int[] expirationDate, int cat, int mySpot) {   //A non-default constructor, with every variable assigned to the argument values
        this.name = name;
        this.imageId = imageId;
        this.amount = amount;
        this.amountType = amountType;
        this.storage = storage;
        this.expirationDate = expirationDate;
        this.category = cat;
        this.mySpot = mySpot;
    }


    public int colorIdentifier(int[] catCol) {
        int catGORY = -1;
        for (int i = 0; i < 5; i++) {
            int[] color = new int[3];
            switch (i) {
                case 0:           //Meat and eggs
                    color = new int[]{240, 46, 46};
                    break;
                case 1:            //Vegetables and fruit
                    color = new int[]{87, 240, 46};
                    break;
                case 2:          //Dairy products
                    color = new int[]{227, 169, 222};
                    break;
                case 3:            //Seafood
                    color = new int[]{46, 192, 240};
                    break;
                case 4:           //Grains and bread
                    color = new int[]{240, 229, 46};
                    break;
            }
            if (Arrays.equals(catCol, color)) {
                catGORY = i;
            }
        }
        return catGORY;
    }

    public boolean amIExpiringSoon() {                                                              //Method to check if the entry's expiration date is close to the current date
        long dayT = (1000L * 60L * 60L * 24L);                                                      //Declare and initialize a variable named "dayT" of type long, to hold 1 day in milliseconds (for easier calculations later)
        String expDates = this.expirationDate[0] + "/" + this.expirationDate[1] + "/" + this.expirationDate[2];
        long sysDate = System.currentTimeMillis();
        long epoch = 0;
        try {
            epoch = new java.text.SimpleDateFormat("dd/MM/yyyy").parse(expDates).getTime() ;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return sysDate >= epoch - (3*dayT);
    }

    public long getExpirationDate(int dayN, int monthN, int yearN) {                                //The method that returns a long for a date when given the day,month and year
        long epoch = 0;
        String date = dayN + "/" + monthN + "/" + yearN;
        try {
            epoch = new java.text.SimpleDateFormat("dd/mm/yyyy").parse(date).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return epoch;
    }
}


        /*
        long dayT = (1000L * 60L * 60L * 24L);                                                      //Declare and initialize a variable named "dayT" of type long, to hold 1 day in milliseconds (for easier calculations later)
        long thisYear = (48L * 365L * dayT) + (12L * dayT); //Jan 01 2018                           //Declare and initialize a variable named "thisYear" of type long, to hold the current year in milliseconds (aoy unused)

        int mFixN = 31;                                                                             //Declares and initializes an integer variable named mFixN with value 31
        int mFix2 = 0;                                                                              //Declares and initializes an integer variable named mFix2 with value 0

        if (monthN < 5 && monthN > 2) {                                                             //The following if statements check the month, and sets the mFix2 variable accordingly, to make the algorithm work with the varying days of the months
            mFix2 = 3;
        } else if (monthN >= 5 && monthN < 7) {
            mFix2 = 4;
        } else if (monthN >= 7 && monthN < 10) {
            mFix2 = 5;
        } else if (monthN >= 10 && monthN < 12) {
            mFix2 = 6;
        } else if (monthN == 12) {
            mFix2 = 7;
        }


        long dateN = ((dayN - 1) * dayT) + ((monthN - 1) * dayT * mFixN - (mFix2 * dayT)) + ((yearN - 1970) * dayT * 365l) + (12l * dayT); //Declares and initializes the variable "dateN", with the algorithm that SHOULD give the correct date translation into a long
        //currentDate.setTime(dateN); //dateN
        // currentDate.toString().substring(4).replace("00:00:00 GMT+00:00 ", "")
        return dateN;                                                                               //returns the calculated long (dateN)
    }

 	long epoch = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse("01/01/1970 01:00:00").getTime() / 1000;

    String date = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new java.util.Date (epoch*1000));
// */

